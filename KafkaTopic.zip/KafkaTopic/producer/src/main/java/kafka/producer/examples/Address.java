package kafka.producer.examples;

public class Address {

}
