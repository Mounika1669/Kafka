package kafka.producer.examples;

class AppConfigs {
    final static String applicationID = "HelloProducer";
    final static String bootstrapServers = "localhost:9092,localhost:9093";
    final static String order_topic = "order";
    final static String order_details_topic = "order-details";
    final static String order_and_order_details_topic = "order-with-order-details";
    final static int numEvents = 1000;
}
