package kafka.producer.examples;

import java.util.Date;

public class OrderDetails {
	
	Date date;
	Integer orderId;
	Date delivaryDate;
	
	public OrderDetails(Date date, Integer orderId, Date delivaryDate) {
		super();
		this.date = date;
		this.orderId = orderId;
		this.delivaryDate = delivaryDate;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Date getDelivaryDate() {
		return delivaryDate;
	}
	public void setDelivaryDate(Date delivaryDate) {
		this.delivaryDate = delivaryDate;
	}

}
