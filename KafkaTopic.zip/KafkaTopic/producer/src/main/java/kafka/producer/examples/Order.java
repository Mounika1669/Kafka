package kafka.producer.examples;

public class Order {

	Integer id;
	String name;
	Address address;
	Double price;
	
	public Order(Integer id, String name, Address address, Double price) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.price = price;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	

}
