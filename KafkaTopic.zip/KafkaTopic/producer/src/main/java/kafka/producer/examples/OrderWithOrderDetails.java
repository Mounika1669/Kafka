package kafka.producer.examples;

public class OrderWithOrderDetails {
	
	Order order;
	OrderDetails details;
	
	public OrderWithOrderDetails(Order order, OrderDetails details) {
		super();
		this.order = order;
		this.details = details;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public OrderDetails getDetails() {
		return details;
	}
	public void setDetails(OrderDetails details) {
		this.details = details;
	}
	

}
