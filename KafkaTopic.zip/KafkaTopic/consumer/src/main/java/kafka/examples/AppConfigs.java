package kafka.examples;

public class AppConfigs {
    public final static String applicationID = "consumer";
    public final static String bootstrapServers = "localhost:9092,localhost:9093";
    public final static String groupID = "cosumeorderGroup";
    public final static String[] sourceTopicNames = {"order","order-details"};
    public final static String order_and_order_details_topic = "order-with-order-details";
  
}
